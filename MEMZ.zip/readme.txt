content of this .zip:

MEMZ_NoGui.exe

    A version of MEMZ-Destructive with admin-prompt but without warning.
    
MEMZ_x64.exe

    MEMZ without warning, including UAC Bypass. Only 64-Bit (check before).
    
    
MEMZ_x86.exe

    Same as before, but for 32-Bit.
    

HOW IT WORKS && HOW TO USE:
I prepared MEMZ with CVE-2017-0213 so that it starts itself with NT AUTHORITY/SYSTEM rights.
Pros:
    - no admin prompt
    - cannot be closed through task manager (insufficient rights, even as admin)
    
Cons:
    - is a bit unstable
    
HOW TO EXECUTE:

Just drop the x86 or the x64 binary on the target system and execute. If MEMZ doesn't immediatly
executes (you see it when notepad pops up), just execute elevatex86.exe (or elevatex64.exe). MEMZ should
then execute.

Happy hunting,
Steve
